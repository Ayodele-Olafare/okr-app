document.addEventListener("DOMContentLoaded", function() {
    fetch('/api/okrs')
        .then(response => response.json())
        .then(data => {
            const okrList = document.getElementById('okr-list');
            data.forEach(okr => {
                let li = document.createElement('li');
                li.innerHTML = `<strong>${okr.objective}</strong><ul>${okr.keyResults.map(kr => `<li>${kr}</li>`).join('')}</ul>`;
                okrList.appendChild(li);
            });
        });
});
